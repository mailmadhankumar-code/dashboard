
import nodemailer from 'nodemailer';
import { Settings, DashboardData } from '@/lib/types';

// In-memory store to track the last time an alert was sent for a specific issue
// Key: [server_id, alert_type, item_name], Value: { timestamp: Date, last_status: 'ok' | 'alert' }
const alert_debounce_store: { [key: string]: { timestamp: Date, last_status: 'ok' | 'alert' } } = {};

// --- Debounce Configuration in Minutes ---
const STATUS_DEBOUNCE_MINUTES = 180; // 3 hours
const DAILY_DEBOUNCE_MINUTES = 1440; // 24 hours


const SMTP_CONFIG = {
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT || "587", 10),
    secure: (process.env.SMTP_PORT || "587") === "465", // true for 465, false for other ports
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASSWORD,
    },
};
const SMTP_SENDER = process.env.SMTP_SENDER || "noreply@proactivedb.com";


export class AlertManager {
    private settings: Settings;
    private transporter: nodemailer.Transporter;

    constructor(settings: Settings) {
        this.settings = settings;
        if(SMTP_CONFIG.host) {
            this.transporter = nodemailer.createTransport(SMTP_CONFIG);
        } else {
            // Create a dummy transporter if no host is configured
            this.transporter = nodemailer.createTransport({jsonTransport: true});
        }
    }

    private _can_send_alert(server_id: string, alert_type: string, item_name: string | number, is_alert_condition: boolean, debounce_minutes: number): boolean {
        const key = `${server_id}|${alert_type}|${String(item_name)}`;
        const now = new Date();
        const last_alert_info = alert_debounce_store[key];

        if (is_alert_condition) {
            // Condition is currently active (e.g., DB is down)
            if (!last_alert_info || last_alert_info.last_status === 'ok') {
                // This is a NEW alert condition (was previously OK or we've never seen it before).
                console.log(`New alert condition for ${key}. Sending alert.`);
                alert_debounce_store[key] = { timestamp: now, last_status: 'alert' };
                return true; // Send the alert
            } else {
                // Condition is ongoing. Check if debounce period has passed.
                const diffMinutes = (now.getTime() - last_alert_info.timestamp.getTime()) / (1000 * 60);
                if (diffMinutes >= debounce_minutes) {
                    console.log(`Debounce period for ${key} has passed. Sending follow-up alert.`);
                    alert_debounce_store[key].timestamp = now; // Reset timer for the next debounce period
                    return true; // Send the alert
                } else {
                    // Still within the debounce period for an ongoing issue.
                    console.log(`Debouncing alert for ${key}. Last alert was ${diffMinutes.toFixed(1)} mins ago.`);
                    return false;
                }
            }
        } else {
            // Condition is currently OK.
            if (last_alert_info && last_alert_info.last_status === 'alert') {
                // The condition has just cleared.
                console.log(`Alert condition for ${key} has cleared.`);
                alert_debounce_store[key].last_status = 'ok';
            } else if (!last_alert_info) {
                // First time seeing this check, and it's OK.
                 alert_debounce_store[key] = { timestamp: now, last_status: 'ok' };
            }
            return false;
        }
    }


    private async _send_email(subject: string, body: string, recipients: string[]) {
        if (!SMTP_CONFIG.host || recipients.length === 0) {
            console.log("SMTP not configured or no recipients, skipping email.");
            console.log(`Subject: ${subject}\nBody: ${body}`);
            return;
        }

        const mailOptions = {
            from: SMTP_SENDER,
            to: recipients.join(', '),
            subject: subject,
            text: body,
        };

        try {
            const info = await this.transporter.sendMail(mailOptions);
            console.log(`Successfully sent alert email to: ${recipients.join(', ')}`, info.response);
        } catch (error: any) {
             if (error.code === 'ECONNREFUSED') {
                console.error(`\n--- SMTP Connection Error ---`);
                console.error(`Failed to connect to SMTP server at ${error.address}:${error.port}.`);
                console.error(`This 'ECONNREFUSED' error means the connection was rejected. Please check the following:`);
                console.error(`1. Verify the SMTP_HOST and SMTP_PORT in your .env.local file are correct.`);
                console.error(`2. Ensure no firewall is blocking outbound connections on port ${error.port}.`);
                console.error(`3. Confirm your SMTP server is running and accessible.`);
                console.error(`---------------------------\n`);
            } else {
                console.error(`Failed to send email: ${error}`);
            }
        }
    }

    async process_alerts(server_id: string, data: DashboardData) {
        console.log(`Processing alerts for ${server_id}...`);
        
        const db_name = data.dbName || "N/A";
        
        const email_settings = this.settings.emailSettings || {};
        const exclusions = this.settings.alertExclusions || {};
        
        // All alerts go to admins
        const admin_emails = email_settings.adminEmails || [];
        const all_recipients = new Set<string>(admin_emails);
        
        // Find customer emails from settings and add them
        for (const cust of (email_settings.customers || [])) {
            if (cust.databases?.some(db => db.id === server_id)) {
                const customer_emails = cust.emails || [];
                if (customer_emails.length > 0) {
                    customer_emails.forEach(email => all_recipients.add(email));
                }
                break;
            }
        }
        
        const recipientsList = Array.from(all_recipients).filter(Boolean);
        
        // --- Check all alert conditions ---
        await this._check_status_alerts(server_id, db_name, data, recipientsList);
        await this._check_threshold_alerts(server_id, db_name, data, recipientsList);
        await this._check_ora_error_alerts(server_id, db_name, data, recipientsList, exclusions);
        await this._check_backup_alerts(server_id, db_name, data, recipientsList);
    }

    private async _check_status_alerts(server_id: string, db_name: string, data: DashboardData, recipients: string[]) {
        if (this._can_send_alert(server_id, "status", "db_down", !data.dbIsUp, STATUS_DEBOUNCE_MINUTES)) {
            const subject = `ALERT: Database Down for ${db_name} (${server_id})`;
            const body = `The database ${db_name} (${server_id}) is currently unreachable or not in an OPEN state. Current status: ${data.dbStatus || 'UNKNOWN'}`;
            await this._send_email(subject, body, recipients);
        }
        
        if (this._can_send_alert(server_id, "status", "os_down", !data.osIsUp, STATUS_DEBOUNCE_MINUTES)) {
            const subject = `ALERT: OS Unreachable for ${db_name} (${server_id})`;
            const body = `The operating system for the server hosting ${db_name} (${server_id}) is not reporting data. The agent may be down or the server may be offline.`;
            await this._send_email(subject, body, recipients);
        }
    }

    private async _check_threshold_alerts(server_id: string, db_name: string, data: DashboardData, recipients: string[]) {
        const thresholds = this.settings.thresholds || { cpu: 90, memory: 90 };
        const exclusions = this.settings.alertExclusions || {};
        const kpis = data.kpis || { cpuUsage: 0, memoryUsage: 0, activeSessions: 0 };

        // CPU
        if (thresholds.cpu) {
            const isAlert = kpis.cpuUsage > thresholds.cpu;
            if (this._can_send_alert(server_id, "threshold", "cpu", isAlert, DAILY_DEBOUNCE_MINUTES)) {
                const subject = `ALERT: High CPU Usage on ${db_name} (${server_id})`;
                const body = `CPU usage is currently at ${kpis.cpuUsage.toFixed(2)}%, exceeding the threshold of ${thresholds.cpu}%.`;
                await this._send_email(subject, body, recipients);
            }
        }

        // Memory
        if (thresholds.memory) {
            const isAlert = kpis.memoryUsage > thresholds.memory;
            if (this._can_send_alert(server_id, "threshold", "memory", isAlert, DAILY_DEBOUNCE_MINUTES)) {
                const subject = `ALERT: High Memory Usage on ${db_name} (${server_id})`;
                const body = `Memory usage is currently at ${kpis.memoryUsage.toFixed(2)}%, exceeding the threshold of ${thresholds.memory}%.`;
                await this._send_email(subject, body, recipients);
            }
        }

        // Disk Usage
        const disk_threshold = this.settings.diskThreshold || 90;
        const excluded_disks = exclusions.excludedDisks || [];
        for (const disk of (data.diskUsage || [])) {
            if (excluded_disks.includes(disk.mount_point)) {
                continue; // Skip excluded disk
            }
            const isAlert = disk.used_percent > disk_threshold;
            if (this._can_send_alert(server_id, "threshold", `disk_${disk.mount_point}`, isAlert, DAILY_DEBOUNCE_MINUTES)) {
                const subject = `ALERT: High Disk Usage on ${db_name} (${server_id})`;
                const body = `Disk usage for mount point '${disk.mount_point}' is at ${disk.used_percent.toFixed(2)}%, exceeding the threshold of ${disk_threshold}%.`;
                await this._send_email(subject, body, recipients);
            }
        }

        // Tablespace Usage
        const ts_threshold = this.settings.tablespaceThreshold || 90;
        for (const ts of (data.tablespaces || [])) {
            const isAlert = ts.used_percent > ts_threshold;
             if (this._can_send_alert(server_id, "threshold", `ts_${ts.name}`, isAlert, DAILY_DEBOUNCE_MINUTES)) {
                const subject = `ALERT: High Tablespace Usage in ${db_name} (${server_id})`;
                const body = `Tablespace '${ts.name}' usage is at ${ts.used_percent.toFixed(2)}%, exceeding the threshold of ${ts_threshold}%.`;
                await this._send_email(subject, body, recipients);
             }
        }
    }

    private async _check_ora_error_alerts(server_id: string, db_name: string, data: DashboardData, recipients: string[], exclusions: { excludedOraErrors?: string[] }) {
        const excluded_errors = exclusions.excludedOraErrors || [];

        const filtered_logs = (data.alertLog || []).filter(log => 
            !excluded_errors.some(prefix => log.error_code.startsWith(prefix))
        );

        for (const log_entry of filtered_logs) {
            // Treat each unique error log line as a separate alert to be debounced
            const alertId = `log_${log_entry.error_code}`;
            if (this._can_send_alert(server_id, "ora_error", alertId, true, DAILY_DEBOUNCE_MINUTES)) {
                 const subject = `ALERT: ORA- Error Detected in ${db_name} (${server_id})`;
                 const body = `An error was found in the alert log for ${db_name} (${server_id}).\n\n- Timestamp: ${log_entry.timestamp}\n- Error: ${log_entry.error_code}`;
                 await this._send_email(subject, body, recipients);
            }
        }
    }
    
    private async _check_backup_alerts(server_id: string, db_name: string, data: DashboardData, recipients: string[]) {
        for (const backup of (data.backups || [])) {
            if (backup.status === 'FAILED') {
                if (this._can_send_alert(server_id, "backup_failed", backup.id, true, DAILY_DEBOUNCE_MINUTES)) {
                    const subject = `ALERT: RMAN Backup Failed for ${db_name} (${server_id})`;
                    const body = `An RMAN backup job for ${db_name} started at ${backup.start_time} has FAILED.`;
                    await this._send_email(subject, body, recipients);
                }
            }
        }
    }
}
