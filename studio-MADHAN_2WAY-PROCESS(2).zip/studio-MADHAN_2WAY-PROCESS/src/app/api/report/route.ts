
import { NextResponse } from "next/server";
import { storePerformanceMetrics, db_data_store } from "@/lib/server/db";
import { DashboardData } from "@/lib/types";
// Import the monitor starter function. Although it auto-starts, importing it ensures it's part of the server bundle.
import '@/lib/server/monitor';


export async function POST(request: Request) {
  try {
    const raw_data = (await request.json());
    
    // --- Data Type Coercion ---
    const data: DashboardData = {
        ...raw_data,
        backups: (raw_data.backups || []).map((b: any) => ({
            ...b,
            input_bytes: b.input_bytes ? Number(b.input_bytes) : 0,
            output_bytes: b.output_bytes ? Number(b.output_bytes) : 0,
            elapsed_seconds: b.elapsed_seconds ? Number(b.elapsed_seconds) : 0,
        }))
    };
    
    const server_id = data.id;
    const timestamp = data.timestamp;

    if (!server_id || !timestamp) {
      return NextResponse.json(
        { error: "Missing 'id' or 'timestamp' in payload" },
        { status: 400 }
      );
    }

    // --- Store historical performance data ---
    await storePerformanceMetrics(server_id, timestamp, data);
    

    // --- Store the latest full snapshot in memory ---
    db_data_store[server_id] = {
      data: data,
      last_updated: new Date().toISOString(),
    };

    // Alerting is now handled by the central background monitor (src/lib/server/monitor.ts)
    // The monitor will pick up this new data on its next run. This decouples reporting from alerting.
    
    console.log(`[${new Date().toISOString()}] Received data from agent: ${server_id}`);
    return NextResponse.json({ status: "success", id: server_id }, { status: 201 });

  } catch (error) {
    console.error("Error processing report:", error);
    if (error instanceof SyntaxError) {
        return NextResponse.json({ error: "Request must be JSON" }, { status: 400 });
    }
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
