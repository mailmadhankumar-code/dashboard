
"use client";

import React, { useState, useEffect, useCallback, useMemo } from "react";
import DashboardLayout from "@/components/dashboard/dashboard-layout";
import DashboardHeader from "@/components/dashboard/header";
import CpuCard from "@/components/dashboard/cpu-card";
import HostMemoryCard from "@/components/dashboard/host-memory-card";
import IoCard from "@/components/dashboard/io-card";
import NetworkCard from "@/components/dashboard/network-card";
import ActiveSessionsCard from "@/components/dashboard/active-sessions-card";
import TablespacesCard from "@/components/dashboard/tablespaces-card";
import RmanBackupsCard from "@/components/dashboard/rman-backups-card";
import AlertLogCard from "@/components/dashboard/alert-log-card";
import DiskUsageCard from "@/components/dashboard/disk-usage-card";
import ActiveSessionHistoryCard from "@/components/dashboard/active-session-history-card";
import TopWaitEventsCard from "@/components/dashboard/top-wait-events-card";
import DetailedActiveSessionsCard from "@/components/dashboard/detailed-active-sessions-card";
import StandbyStatusCard from "@/components/dashboard/standby-status-card";
import { useSession } from "@/hooks/use-session";
import { toast } from "@/hooks/use-toast";
import { initialData } from "@/lib/mock-data";
import type { Customer, Alert, Settings, DashboardData, UserSession, OverviewRow } from "@/lib/types";
import { Loader2, Server } from "lucide-react";
import { useRouter } from "next/navigation";


const STATUS_TIMEOUT_SECONDS = 90;

export default function Home() {
  const router = useRouter();
  const { session, isLoading: isSessionLoading } = useSession();
  
  const [allData, setAllData] = useState<{ [key: string]: DashboardData }>({});
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedDbId, setSelectedDbId] = useState<string>("");
  const [isLoading, setIsLoading] = useState(true);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);

  // Effect for fetching settings and initializing customers and selected DB
  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await fetch("/api/settings");
        if (!response.ok) throw new Error("Failed to fetch settings");
        const settingsData: Settings = await response.json();
        setSettings(settingsData);

        let userCustomers = settingsData.emailSettings?.customers || [];
        if (session && session.role === 'user' && session.customerIds) {
          userCustomers = userCustomers.filter(c => session.customerIds.includes(c.id));
        }

        const initializedCustomers = userCustomers.map(c => ({
          ...c,
          databases: c.databases.map(db => ({ ...db, isUp: false, osUp: false })),
        }));
        setCustomers(initializedCustomers);

        // Determine the initial selected DB
        const storedDbId = localStorage.getItem("selectedDbId");
        if (storedDbId && userCustomers.flatMap(c => c.databases).some(db => db.id === storedDbId)) {
          setSelectedDbId(storedDbId);
        } else if (userCustomers.length > 0 && userCustomers[0].databases.length > 0) {
          const firstDbId = userCustomers[0].databases[0].id;
          setSelectedDbId(firstDbId);
          localStorage.setItem("selectedDbId", firstDbId);
        } else {
           setIsLoading(false); // No DBs to load
        }
      } catch (error) {
        console.error("Failed to fetch initial settings:", error);
        toast({ title: "Error", description: "Could not load application settings.", variant: "destructive" });
      }
    };

    if (session) {
      fetchSettings();
    }
  }, [session]);


  // Data fetching poll for the selected DB
  useEffect(() => {
    if (!selectedDbId || !session) return;
    
    let isCancelled = false;

    const fetchData = async () => {
      setIsLoading(true);
      try {
        const res = await fetch(`/api/data/${selectedDbId}`);
        if (!res.ok) throw new Error(`Failed to fetch data for ${selectedDbId}`);
        const data = await res.json();
        
        if (!isCancelled) {
            setAllData(prevData => ({ ...prevData, [selectedDbId]: data.data }));
            setCustomers(prevCustomers => {
              const now = new Date();
              return prevCustomers.map(c => ({
                ...c,
                databases: c.databases.map(db => {
                   if (db.id === selectedDbId) {
                      return { ...db, isUp: data.data.dbIsUp, osUp: data.data.osIsUp };
                   }
                   // Note: Other DB statuses are not updated in this poll to avoid loops.
                   // The overview page is responsible for fetching all statuses.
                   return db;
                })
              }))
            });
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        toast({ title: "Data Fetch Error", description: (error as Error).message, variant: "destructive" });
      } finally {
        if (!isCancelled) setIsLoading(false);
      }
    };

    fetchData(); // Initial fetch
    const interval = setInterval(fetchData, 10000); // Poll every 10 seconds

    return () => {
      isCancelled = true;
      clearInterval(interval);
    };

  }, [selectedDbId, session]);

  const handleDbSelect = useCallback((dbId: string) => {
    setSelectedDbId(dbId);
    localStorage.setItem("selectedDbId", dbId);
    router.push('/');
  }, [router]);

  const selectedDbData = useMemo(() => allData[selectedDbId] || initialData, [allData, selectedDbId]);
  
  const selectedDbCustomerInfo = useMemo(() => {
      for (const customer of customers) {
          const db = customer.databases.find(d => d.id === selectedDbId);
          if (db) {
              return {
                  id: db.id,
                  name: db.name,
                  customerName: customer.name,
                  dbStatus: selectedDbData.dbStatus || 'UNKNOWN',
                  osType: selectedDbData.osInfo?.platform || 'Unknown'
              };
          }
      }
      return { id: selectedDbId, name: selectedDbId, customerName: 'Unknown', dbStatus: 'UNKNOWN', osType: 'Unknown' };
  }, [customers, selectedDbId, selectedDbData]);


  if (isSessionLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <DashboardLayout
      customers={customers}
      selectedDbId={selectedDbId}
      onDbSelect={handleDbSelect}
      alerts={alerts}
      session={session}
    >
        {selectedDbId ? (
            <>
                <DashboardHeader
                    kpis={selectedDbData.kpis}
                    selectedDb={selectedDbCustomerInfo}
                />
                <main className="grid flex-1 auto-rows-max grid-cols-1 gap-4 p-4 md:grid-cols-2 md:gap-6 lg:grid-cols-4 xl:grid-cols-6">
                    {isLoading && <div className="absolute inset-0 bg-background/50 flex items-center justify-center z-20"><Loader2 className="h-8 w-8 animate-spin" /></div>}
                    <div className="lg:col-span-2 xl:col-span-6">
                        <CpuCard data={selectedDbData.performance?.cpu} />
                    </div>
                    <div className="lg:col-span-2 xl:col-span-6">
                        <HostMemoryCard data={selectedDbData.performance?.memory} />
                    </div>
                    <div className="lg:col-span-2 xl:col-span-6">
                        <IoCard
                            readData={selectedDbData.performance?.io_read}
                            writeData={selectedDbData.performance?.io_write}
                            diskUsage={selectedDbData.diskUsage}
                        />
                    </div>
                    <div className="lg:col-span-2 xl:col-span-6">
                        <NetworkCard
                            upData={selectedDbData.performance?.network_up}
                            downData={selectedDbData.performance?.network_down}
                        />
                    </div>
                    <div className="lg:col-span-2 xl:col-span-3">
                         <ActiveSessionHistoryCard sessionHistory={selectedDbData.activeSessionsHistory} />
                    </div>
                     <div className="lg:col-span-2 xl:col-span-3">
                        <TopWaitEventsCard waitEvents={selectedDbData.topWaitEvents} />
                    </div>
                    <div className="lg:col-span-2 xl:col-span-6">
                        <StandbyStatusCard standbyStatus={selectedDbData.standbyStatus} />
                    </div>
                    <div className="lg:col-span-2 xl:col-span-6">
                         <RmanBackupsCard backups={selectedDbData.backups} />
                    </div>
                     <div className="lg:col-span-2 xl:col-span-3">
                        <TablespacesCard tablespaces={selectedDbData.tablespaces} threshold={settings?.tablespaceThreshold} />
                    </div>
                     <div className="lg:col-span-2 xl:col-span-3">
                        <DiskUsageCard diskUsage={selectedDbData.diskUsage} threshold={settings?.diskThreshold} excludedDisks={settings?.alertExclusions?.excludedDisks} />
                    </div>
                     <div className="lg:col-span-2 xl:col-span-3">
                        <ActiveSessionsCard sessions={selectedDbData.activeSessions} />
                    </div>
                     <div className="lg:col-span-2 xl:col-span-3">
                        <AlertLogCard alerts={selectedDbData.alertLog} excludedErrors={settings?.alertExclusions?.excludedOraErrors} />
                    </div>
                     <div className="lg:col-span-4 xl:col-span-6">
                        <DetailedActiveSessionsCard sessions={selectedDbData.detailedActiveSessions} />
                    </div>
                </main>
            </>
        ) : (
            <div className="flex h-full flex-col items-center justify-center p-4">
                <Server className="h-16 w-16 text-muted-foreground" />
                <h2 className="mt-4 text-xl font-semibold">No Database Selected</h2>
                <p className="mt-2 text-center text-muted-foreground">
                    Please select a database from the sidebar to view its dashboard.
                </p>
            </div>
        )}
    </DashboardLayout>
  );
}
