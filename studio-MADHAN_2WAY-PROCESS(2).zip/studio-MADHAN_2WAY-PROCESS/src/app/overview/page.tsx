
"use client";

import React, { useState, useEffect, useCallback } from "react";
import DashboardLayout from "@/components/dashboard/dashboard-layout";
import { useSession } from "@/hooks/use-session";
import { toast } from "@/hooks/use-toast";
import type { Customer, Alert, Settings, OverviewRow } from "@/lib/types";
import {
  Server,
  Cpu,
  MemoryStick,
  Users,
  CheckCircle,
  XCircle,
  Loader2,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { useRouter } from "next/navigation";

const StatusIndicator = ({
  isUp,
  label,
}: {
  isUp: boolean;
  label: string;
}) => (
  <div className="flex items-center gap-2">
    <span
      className={cn(
        "h-2.5 w-2.5 rounded-full",
        isUp ? "bg-green-500" : "bg-red-500"
      )}
    />
    <span className="text-sm">
      {label}:{" "}
      <span className={cn("font-semibold", isUp ? "text-foreground" : "text-red-400")}>
        {isUp ? "Up" : "Down"}
      </span>
    </span>
  </div>
);

const KpiItem = ({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string | number;
}) => (
  <div className="flex items-center justify-between text-sm">
    <div className="flex items-center gap-2 text-muted-foreground">
      {icon}
      <span>{label}</span>
    </div>
    <span className="font-mono font-medium text-foreground">{value}</span>
  </div>
);

const DatabaseCard = ({
  db,
  onClick,
}: {
  db: OverviewRow;
  onClick: (id: string) => void;
}) => (
  <Card
    className="flex flex-col cursor-pointer transition-all duration-300 hover:shadow-primary/20 hover:border-border/60"
    onClick={() => onClick(db.id)}
  >
    <CardHeader>
      <div className="flex items-start justify-between">
        <div>
          <CardTitle>{db.dbName}</CardTitle>
          <CardDescription>{db.customerName}</CardDescription>
        </div>
        <Badge variant="outline">{db.dbStatus}</Badge>
      </div>
    </CardHeader>
    <CardContent className="flex-grow space-y-3">
      <KpiItem icon={<Cpu className="h-4 w-4" />} label="CPU Usage" value={`${db.cpuUsage.toFixed(1)}%`} />
      <KpiItem icon={<MemoryStick className="h-4 w-4" />} label="Memory Usage" value={`${db.memoryUsage.toFixed(1)}%`} />
      <KpiItem icon={<Users className="h-4 w-4" />} label="Active Sessions" value={db.activeSessions} />
    </CardContent>
    <CardFooter className="flex gap-4 text-sm">
      <StatusIndicator isUp={db.dbIsUp} label="DB" />
      <StatusIndicator isUp={db.osIsUp} label="OS" />
    </CardFooter>
  </Card>
);

export default function OverviewPage() {
  const { session, isLoading: isSessionLoading } = useSession();
  const [data, setData] = useState<OverviewRow[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();

  const [customers, setCustomers] = useState<Customer[]>([]);
  const [alerts] = useState<Alert[]>([]);

  useEffect(() => {
    if (isSessionLoading || !session) return;

    const fetchInitialData = async () => {
      try {
        const settingsResponse = await fetch("/api/settings");
        if (!settingsResponse.ok) throw new Error("Failed to fetch settings");
        const settingsData: Settings = await settingsResponse.json();

        let allCustomers = settingsData?.emailSettings?.customers || [];
        if (session.role === "user" && session?.customerIds) {
          allCustomers = allCustomers.filter((c) =>
            session.customerIds?.includes(c.id)
          );
        }

        const initialCustomers = allCustomers.map((c) => ({
          ...c,
          databases: c.databases.map((db) => ({ ...db, isUp: false, osUp: false })),
        }));
        setCustomers(initialCustomers);
      } catch (error) {
        console.error("Failed to fetch initial settings for sidebar:", error);
      }
    };
    fetchInitialData();
  }, [isSessionLoading, session]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        const response = await fetch("/api/overview");
        if (!response.ok) {
          if (response.status === 401) {
             router.push('/login');
             return;
          }
          throw new Error("Failed to fetch overview data");
        }
        const result: OverviewRow[] = await response.json();
        setData(result);

        // Update customer status in sidebar
        setCustomers(prevCustomers => {
            return prevCustomers.map(c => ({
                ...c,
                databases: c.databases.map(db => {
                    const overviewData = result.find(d => d.id === db.id);
                    return {
                        ...db,
                        isUp: overviewData?.dbIsUp ?? false,
                        osUp: overviewData?.osIsUp ?? false,
                    };
                })
            }));
        });
        
      } catch (error) {
        console.error(error);
        toast({
          title: "Error fetching data",
          description: (error as Error).message,
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    if(session) {
      fetchData();
      const interval = setInterval(fetchData, 15000); // Poll every 15 seconds
      return () => clearInterval(interval);
    }
  }, [session, router]);

  const handleDbSelect = useCallback(
    (dbId: string) => {
      localStorage.setItem("selectedDbId", dbId);
      router.push("/");
    },
    [router]
  );

  return (
    <DashboardLayout
      customers={customers}
      selectedDbId={""} // No DB is "selected" on the overview page itself
      onDbSelect={handleDbSelect}
      alerts={alerts}
      session={session}
    >
      <header className="sticky top-0 z-10 flex h-auto min-h-16 items-center gap-4 border-b bg-background/80 p-4 backdrop-blur-lg md:px-6">
        <h1 className="text-xl font-semibold">Databases Overview</h1>
      </header>

      <main className="flex-1 p-4 md:p-6">
        {isLoading && data.length === 0 ? (
          <div className="flex justify-center items-center h-full">
            <div className="text-center">
              <Loader2 className="h-8 w-8 animate-spin mx-auto mb-2" />
              <p className="text-muted-foreground">Loading databases...</p>
            </div>
          </div>
        ) : data.length > 0 ? (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:gap-6 lg:grid-cols-3 xl:grid-cols-4">
            {data.map((db) => (
              <DatabaseCard key={db.id} db={db} onClick={handleDbSelect} />
            ))}
          </div>
        ) : (
          <div className="flex justify-center items-center h-full">
            <div className="text-center">
              <Server className="h-12 w-12 mx-auto text-muted-foreground" />
              <h2 className="mt-4 text-lg font-semibold">No Databases Found</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                No databases are configured for your account.
              </p>
            </div>
          </div>
        )}
      </main>
    </DashboardLayout>
  );
}
