import React from "react";
import { GlassCard, CardHeader, CardTitle, CardContent, CardDescription } from "./glass-card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { AlertLogEntry } from "@/lib/types";

interface AlertLogCardProps {
  alerts: AlertLogEntry[];
  excludedErrors?: string[];
}

export default function AlertLogCard({ alerts = [], excludedErrors = [] }: AlertLogCardProps) {
  
  const filteredAlerts = alerts.filter(alert => 
    !excludedErrors.some(prefix => alert.error_code.startsWith(prefix))
  );

  return (
    <GlassCard>
      <CardHeader>
        <CardTitle>Alert Log Errors</CardTitle>
        <CardDescription>Recent ORA- errors from the alert log.</CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-64">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Timestamp</TableHead>
                <TableHead>Error</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAlerts.length === 0 ? (
                <TableRow>
                    <TableCell colSpan={2} className="h-24 text-center">
                        No recent errors to display.
                    </TableCell>
                </TableRow>
              ) : (
                filteredAlerts.map((alert) => (
                    <TableRow key={alert.id}>
                    <TableCell className="text-xs">{alert.timestamp}</TableCell>
                    <TableCell className="font-mono font-bold text-red-400 text-xs">{alert.error_code}</TableCell>
                    </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </ScrollArea>
      </CardContent>
    </GlassCard>
  );
}
