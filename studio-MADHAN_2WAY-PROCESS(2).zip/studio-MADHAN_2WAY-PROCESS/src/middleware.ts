
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { getSession } from '@/lib/server/session';

const protectedRoutes = ['/', '/overview'];
const publicRoutes = ['/login'];

export async function middleware(request: NextRequest) {
  const path = request.nextUrl.pathname;
  
  // Use startsWith to correctly handle sub-paths if any are added in the future
  const isProtectedRoute = protectedRoutes.some(p => path === p || (p !== '/' && path.startsWith(p)));

  // 1. Get and decrypt the session
  const session = await getSession();

  // 2. Redirect to login if user is not authenticated and trying to access a protected route
  if (isProtectedRoute && !session) {
    return NextResponse.redirect(new URL('/login', request.nextUrl));
  }

  // 3. Redirect to overview if user is authenticated and trying to access the login page
  if (path === '/login' && session) {
     return NextResponse.redirect(new URL('/overview', request.nextUrl));
  }
  
  // If user is authenticated and at the root, go to overview.
  if (path === '/' && session) {
     return NextResponse.redirect(new URL('/overview', request.nextUrl));
  }
  
  // If a request is made to the incorrect capitalized path, redirect to the correct one.
  if (path === '/Overview') {
    return NextResponse.redirect(new URL('/overview', request.nextUrl));
  }

  return NextResponse.next();
}

// See "Matching Paths" below to learn more
export const config = {
  // We exclude /api/report so the python agent can post data without auth
  // We exclude static assets and images
  matcher: ['/((?!api/report|_next/static|_next/image|favicon.ico).*)'],
}
