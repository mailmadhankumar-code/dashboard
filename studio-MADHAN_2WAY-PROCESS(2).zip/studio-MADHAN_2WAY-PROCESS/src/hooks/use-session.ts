
"use client";

import { useState, useEffect, useCallback, useMemo } from 'react';
import type { UserSession } from '@/lib/types';

// This is a module-level cache to hold the session data.
let cachedSession: UserSession | null = null;
let sessionPromise: Promise<void> | null = null;

export function useSession() {
  const [sessionData, setSessionData] = useState<UserSession | null>(cachedSession);
  const [isLoading, setIsLoading] = useState(!cachedSession);

  const fetchSession = useCallback(async () => {
    // If we're already fetching, don't start another fetch.
    if (sessionPromise) {
      await sessionPromise;
      return;
    }
    
    // Set up the promise so other concurrent calls can wait for it.
    sessionPromise = (async () => {
      setIsLoading(true);
      try {
        const res = await fetch('/api/auth/session');
        
        if (res.ok) {
          const data = await res.json();
          cachedSession = data.user;
          setSessionData(data.user);
        } else {
          cachedSession = null;
          setSessionData(null);
        }
      } catch (error) {
        console.error('Failed to fetch session:', error);
        cachedSession = null;
        setSessionData(null);
      } finally {
        setIsLoading(false);
        // Clear the promise once it's resolved.
        sessionPromise = null;
      }
    })();

    await sessionPromise;
  }, []);

  useEffect(() => {
    // Only fetch if the session hasn't been fetched yet.
    if (cachedSession === null && !sessionPromise) {
        fetchSession();
    }
  }, [fetchSession]);

  // Revalidate function exposed to the caller.
  const revalidate = useCallback(async () => {
    // Invalidate the cache and re-fetch.
    cachedSession = null;
    await fetchSession();
  }, [fetchSession]);
  
  return { 
    session: sessionData, 
    isLoading, 
    revalidate 
  };
}

    